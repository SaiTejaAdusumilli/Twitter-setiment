import re # for regular expressions
import pandas as pd 
pd.set_option("display.max_colwidth", 200)
import numpy as np 
import matplotlib.pyplot as plt 
import seaborn as sns
import string
import nltk # for text manipulation
import warnings 
warnings.filterwarnings("ignore", category=DeprecationWarning)


df=pd.read_csv("C://Users//Asus//Desktop//senti//combined.csv", sep=",", header=0)

arr=['very bad move taken by obama']
c=arr[0]
c=str(c)
combi=df.drop(['id','created_at'],axis=1)

import re
from string import punctuation
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

#start process_tweet
def processTweet(tweet):
    lemma  = WordNetLemmatizer()
    
    tweet = tweet.lower()
    
    tweet = re.sub('((www\.[^\s]+)|(https?://[^\s]+))',' ',tweet)
 
    tweet = re.sub('@[^\s]+',' ',tweet)
    
    tweet = re.sub('[\s]+', ' ', tweet)
    
    tweet = tweet.strip('\'"')
    
    tweet = re.sub("[^a-zA-Z#]", " ",tweet)

    tweet=' '.join(lemma.lemmatize(word) for word in tweet.split() if word not in stopwords.words('english'))
    
    return tweet

for i in combi['text']:
    combi['text']=combi['text'].replace(i,processTweet(i))


combi['text'] = combi['text'].apply(lambda x: ' '.join([w for w in x.split() if len(w)>3]))




c=processTweet(c)




t=""
for i in c.split():
    if(len(i)>3):
        t=t+i+" "





t




#xxx=combi




import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
#nltk.download('vader_lexicon')
sid = SentimentIntensityAnalyzer()
x=[]
c1=0
c2=0
c3=0
c4=0
for text in combi['text']:
    score = sid.polarity_scores(text)
    if(score['compound']>0.4):
        x.append(1)
        c1=c1+1
    elif(score['compound']<-0.4):
        x.append(-1)
        c2=c2+1
    else:
        x.append(0)
        c3=c3+1
    c4=c4+1
#     else:
#         x.append(1)



# In[90]:
print("--------->",c1,c2,c3,c4)


#combi = pd.DataFrame()



#print(x)
print(len(x),combi.shape)
combi['label']=x

#print(combi.head(5))


c1=pd.DataFrame({"text":[t],"label":[0]}) 




combi=combi.append(c1,ignore_index = True)




print(combi.head())


'''
all_words = ' '.join([text for text in combi['text']])
from wordcloud import WordCloud
wordcloud = WordCloud(width=800, height=500, random_state=21, max_font_size=110).generate(all_words)

plt.figure(figsize=(10, 7))
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis('off')
plt.show()


# In[46]:


negative_words =' '.join([text for text in combi['text'][combi['label'] == 0]]) 
wordcloud = WordCloud(width=800, height=500, random_state=21, max_font_size=110).generate(negative_words)
plt.figure(figsize=(10, 7))
plt.imshow(wordcloud, interpolation="bilinear")
plt.axis('off')
plt.show()


# In[47]:



if(combi["label"][0]==1):
    pos_words = ' '.join([text for text in combi['text'][combi['label'] == 1]])
    wordcloud = WordCloud(width=800, height=500,
    random_state=21, max_font_size=110).generate(pos_words)
    plt.figure(figsize=(10, 7))
    plt.imshow(wordcloud, interpolation="bilinear")
    plt.axis('off')
    plt.show()


# In[98]:


def hashtag_extract(x):
    hashtags = []
    # Loop over the words in the tweet
    for i in x:
        ht = re.findall(r"#(\w+)", i)
        hashtags.append(ht)

    return hashtags


# In[81]:


# extracting hashtags from non racist/sexist tweets

#HT_regular = hashtag_extract(combi['text'][combi['label'] == 1])

# extracting hashtags from racist/sexist tweets
HT_negative = hashtag_extract(combi['text'][combi['label'] == 0])

HT_positive = hashtag_extract(combi['text'][combi['label'] == 1])

# unnesting list
#HT_regular = sum(HT_regular,[])
HT_negative = sum(HT_negative,[])
HT_positive = sum(HT_positive,[])


# In[50]:


if(combi["label"][0]==0):
    
    a = nltk.FreqDist(HT_negative)
    d = pd.DataFrame({'Hashtag': list(a.keys()),
                      'Count': list(a.values())})

    # selecting top 20 most frequent hashtags     
    d = d.nlargest(columns="Count", n = 5) 
    plt.figure(figsize=(10,5))
    ax = sns.barplot(data=d, x= "Hashtag", y = "Count")
    ax.set(ylabel = 'Count')
    plt.show()


# In[52]:


if(combi["label"][0]==1):
    a = nltk.FreqDist(HT_positive)
    d = pd.DataFrame({'Hashtag': list(a.keys()),
                      'Count': list(a.values())})
    # selecting top 20 most frequent hashtags     
    d = d.nlargest(columns="Count", n = 5) 
    plt.figure(figsize=(10,5))
    ax = sns.barplot(data=d, x= "Hashtag", y = "Count")
    ax.set(ylabel = 'Count')
    plt.show()
    

'''


combi.columns=['tidy_tweet','label']





combi





from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
import gensim



bow_vectorizer = CountVectorizer(max_df=0.90, min_df=2, max_features=1000, stop_words='english')
bow = bow_vectorizer.fit_transform(combi['tidy_tweet'])
bow.shape



tfidf_vectorizer = TfidfVectorizer(max_df=0.90, min_df=2, max_features=1000, stop_words='english')
tfidf = tfidf_vectorizer.fit_transform(combi['tidy_tweet'])
tfidf.shape




'''
tokenized_tweet = combi['tidy_tweet'].apply(lambda x: x.split()) # tokenizing

model_w2v = gensim.models.Word2Vec(
            tokenized_tweet,
            size=200, # desired no. of features/independent variables 
            window=5, # context window size
            min_count=2,
            sg = 1, # 1 for skip-gram model
            hs = 0,
            negative = 10, # for negative sampling
            workers= 2, # no.of cores
            seed = 34)

model_w2v.train(tokenized_tweet, total_examples= len(combi['tidy_tweet']), epochs=20)


# In[153]:


def word_vector(tokens, size):
    vec = np.zeros(size).reshape((1, size))
    count = 0.
    for word in tokens:
        try:
            vec += model_w2v[word].reshape((1, size))
            count += 1.
        except KeyError: # handling the case where the token is not in vocabulary
                         
            continue
    if count != 0:
        vec /= count
    return vec


# In[154]:


wordvec_arrays = np.zeros((len(tokenized_tweet), 200))

for i in range(len(tokenized_tweet)):
    wordvec_arrays[i,:] = word_vector(tokenized_tweet[i], 200)
    
wordvec_df = pd.DataFrame(wordvec_arrays)
wordvec_df.shape    


# In[155]:


from tqdm import tqdm
tqdm.pandas(desc="progress-bar")
from gensim.models.doc2vec import LabeledSentence


# In[156]:


def add_label(twt):
    output = []
    for i, s in zip(twt.index, twt):
        output.append(LabeledSentence(s, ["tweet_" + str(i)]))
    return output


# In[157]:


labeled_tweets = add_label(tokenized_tweet) # label all the tweets


# In[158]:


labeled_tweets[:6]


# In[159]:


model_d2v = gensim.models.Doc2Vec(dm=1, # dm = 1 for ‘distributed memory’ model 
                                  dm_mean=1, # dm = 1 for using mean of the context word vectors
                                  size=200, # no. of desired features
                                  window=5, # width of the context window
                                  negative=7, # if > 0 then negative sampling will be used
                                  min_count=5, # Ignores all words with total frequency lower than 2.
                                  workers=3, # no. of cores
                                  alpha=0.1, # learning rate
                                  seed = 23)

model_d2v.build_vocab([i for i in tqdm(labeled_tweets)])


# In[160]:


model_d2v.train(labeled_tweets, total_examples= len(combi['tidy_tweet']), epochs=15)


# In[161]:


docvec_arrays = np.zeros((len(tokenized_tweet), 200))

for i in range(len(combi)):
    docvec_arrays[i,:] = model_d2v.docvecs[i].reshape((1,200))
    
docvec_df = pd.DataFrame(docvec_arrays)
docvec_df.shape


# In[162]:





# In[163]:


#combi


# In[170]:


#bow.shape


# In[171]:
'''

fff=bow[len(combi)-1]





test=combi[:1602]
train=combi[:4808]


# In[173]:


len(train)


# In[174]:


len(test)


# In[175]:


from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score


# In[176]:


train_bow = bow[:4808,:]
test_bow = bow[:1602,:]

# splitting data into training and validation set
xtrain_bow, xvalid_bow, ytrain, yvalid = train_test_split(train_bow, train['label'],  
                                                          random_state=42, 
                                                          test_size=0.3)


# In[177]:
from sklearn.linear_model import LogisticRegression
#X, y = load_iris(return_X_y=True)
lreg = LogisticRegression(random_state=0, solver='lbfgs',
                         multi_class='multinomial').fit(xtrain_bow, ytrain)

#lreg = LogisticRegression()
#lreg.fit(xtrain_bow, ytrain) # training the model

prediction = lreg.predict_proba(xvalid_bow) # predicting on the validation set
prediction_int = prediction[:,1] >= 0.3# if prediction is greater than or equal to 0.3 than 1 else 0
prediction_int = prediction_int.astype(np.int)
'''if(prediction[:,1] >= 0.4):
    prediction_int=1
elif(prediction[:,1]<= -0.4):
    prediction_int= -1
else:
    prediction_int=0
'''
#f1_score(yvalid, prediction_int) # calculating f1 score


# In[178]:


test_pred = lreg.predict_proba(test_bow)
test_pred_int = test_pred[:,1] >= 0.3
test_pred_int = test_pred_int.astype(np.int)
# test['label'] = test_pred_int
# submission = test[['label']]
# submission.to_csv('sub_lreg_bow.csv', index=False) # writing data to a CSV file


# In[179]:


from sklearn.metrics import accuracy_score
print(accuracy_score(test['label'],test_pred_int))
model = lreg
import pickle

filename = 'C://Users//Asus//Desktop//flask//delete.sav'
pickle.dump(model, open(filename, 'wb'))
# In[181]:


ggg=tfidf[len(combi)-1]


# In[182]:


fffpred = lreg.predict_proba(fff)

print(fffpred)
# In[184]:


#prediction_int = fffpred[:,1] >= 0.3 # if prediction is greater than or equal to 0.3 than 1 else 0
#prediction_int = prediction_int.astype(np.int)
'''if(fffpred >= 0.4):
    prediction_int1=1
elif(fffpred <= -0.4):
    prediction_int1= -1
else:
    prediction_int1=0


# In[185]:


print(prediction_int1)


# In[186]:


train_tfidf = tfidf[:4808]
test_tfidf = tfidf[:1602]

xtrain_tfidf = train_tfidf[ytrain.index]
xvalid_tfidf = train_tfidf[yvalid.index]


# In[191]:


lreg.fit(xtrain_tfidf, ytrain)

prediction = lreg.predict_proba(xvalid_tfidf)
prediction
gggpred= lreg.predict_proba(ggg)
gggpred


# In[192]:


#prediction_int = gggpred[:,1] >= 0.3
#prediction_int = prediction_int.astype(np.int)
if(gggpred >= 0.4):
    prediction_int=1
if(gggpred <= -0.4):
    prediction_int= -1
else:
    prediction_int=0
'''

# In[195]:


'''prediction_int = prediction[:,1] >= 0.3
prediction_int = prediction_int.astype(np.int)

f1_score(yvalid, prediction_int)'''
#print(prediction_int[0])

#print(combi.head(15))
