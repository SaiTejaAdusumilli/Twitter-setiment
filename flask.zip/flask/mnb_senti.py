import re # for regular expressions
import pandas as pd 
pd.set_option("display.max_colwidth", 200)
import numpy as np 
import matplotlib.pyplot as plt 
import seaborn as sns
import string
import nltk # for text manipulation
import warnings 
warnings.filterwarnings("ignore", category=DeprecationWarning)

#df=pd.read_csv("C://Users//Asus//Desktop//senti//combined.csv", sep=",", header=0)
import pandas as pd
df = pd.read_csv("C://Users//Asus//Desktop//senti//trump.csv", sep=",", header=0)
df = df["text"]
df1 = pd.read_csv("C://Users//Asus//Desktop//senti//modi.csv", sep=",", header=0)
df1= df1["text"]
combi=pd.concat([df,df1],ignore_index= True)
#combi=pd.concat([df,df1],ignore_index= True)
combi=pd.DataFrame(combi,columns=['text'])
print(combi.head())


print("recieved, takes time ----------->")
#message = request.form['message']
message="Wtf does it matter who he  or  she is? The allegations have all been corroborated from staff and from  trump  himself"
c=str(message)
print("<----------------taken tweet is : ", c,"----------->")
#combi=df.drop(['id','created_at'],axis=1)

import re
from string import punctuation
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
wordlist =set([w for w in nltk.corpus.words.words('en') if w.islower()])
#start process_tweet
stopwordss=['i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're", "you've", "you'll", "you'd", 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', "she's", 'her', 'hers', 'herself', 'it', "it's", 'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', "that'll", 'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such','only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', "don't", 'should', "should've", 'now', 'd', 'll', 'm', 'o', 're', 've', 'y']
print("@@@@@@")
def processTweet(tweet):
    lemma  = WordNetLemmatizer()
    
    tweet = tweet.lower()
    
    tweet = re.sub('((www\.[^\s]+)|(https?://[^\s]+))',' ',tweet)
 
    tweet = re.sub('@[^\s]+',' ',tweet)
    
    tweet = re.sub('[\s]+', ' ', tweet)
    
    tweet = tweet.strip('\'"')
    
    tweet = re.sub("[^a-zA-Z#]", " ",tweet)
    print("lllllllllllllll")
    tweet=' '.join(word  for word in tweet.split() if word not in set(stopwordss))

    tweet=' '.join(word for word in tweet.split() if word  in wordlist)
    
    return tweet

for i in combi['text']:
    combi['text']=combi['text'].replace(i,processTweet(i))

print("WWWW")
combi['text'] = combi['text'].apply(lambda x: ' '.join([w for w in x.split() if len(w)>=2]))




c=processTweet(c)


'''

t=""
for i in c.split():
    if(len(i)>3):
        t=t+i+" "





t
'''



#xxx=combi


print("jjjjjjjjjjjjjjjj")

import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
#nltk.download('vader_lexicon')
sid = SentimentIntensityAnalyzer()
x=[]
c1=0
c2=0
c3=0
c4=0
for text in combi['text']:
    score = sid.polarity_scores(text)
    if(score['compound']>0.4):
        x.append(1)
        c1=c1+1
    elif(score['compound']<-0.4):
        x.append(-1)
        c2=c2+1
    else:
        x.append(0)
        c3=c3+1
    c4=c4+1
#     else:
#         x.append(1)



# In[90]:
print("--------->",c1,c2,c3,c4)


#combi = pd.DataFrame()



#print(x)
print(len(x),combi.shape)
combi['label']=x

#print(combi.head(5))
combi.to_csv('C://Users//Asus//Desktop//senti//final.csv') 
'''
c1=pd.DataFrame({"text":[t],"label":[0]}) 




combi=combi.append(c1,ignore_index = True)

combi.columns=['tidy_tweet','label']











from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
import gensim



bow_vectorizer = CountVectorizer(max_df=0.90, min_df=2, max_features=1000, stop_words='english')
bow = bow_vectorizer.fit_transform(combi['tidy_tweet'])
bow.shape



tfidf_vectorizer = TfidfVectorizer(max_df=0.90, min_df=2, max_features=1000, stop_words='english')
tfidf = tfidf_vectorizer.fit_transform(combi['tidy_tweet'])
tfidf.shape

fff=tfidf[len(combi)-1]





#test=combi[:1602]
#train=combi[:4808]

#train_bow = bow[:4808,:]
#test_bow = bow[:1602,:]
from sklearn.model_selection import train_test_split
# splitting data into training and validation set
xtrain_bow, xvalid_bow, ytrain, yvalid = train_test_split(tfidf, combi['label'],  
                                                          random_state=42, 
                                                          test_size=0.3)



from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
mnb = MultinomialNB(alpha=.01)
mnb.fit(xtrain_bow, ytrain)
mnb_y_pred = mnb.predict(xvalid_bow)
print(accuracy_score(yvalid , mnb_y_pred))

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
logreg = LogisticRegression(C=0.1).fit(xtrain_bow, ytrain)
y_pred = logreg.predict(xvalid_bow)
print(accuracy_score(yvalid, y_pred))
pred = logreg.predict(fff)
print(pred)
model=logreg
import pickle

filename = 'C://Users//Asus//Desktop//flask//fm.sav'
pickle.dump(model, open(filename, 'wb'))
print(combi.head())
'''
print(combi.head())
