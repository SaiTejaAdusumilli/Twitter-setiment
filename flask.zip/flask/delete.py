'''import pickle
filename = 'C://Users//Asus//Desktop//flask//delete.sav'
loaded_model = pickle.load(open(filename, 'rb'))
fff=bow[len(combi)-1]
result = loaded_model.predict_proba(fff)
print(result)
'''
a =['I','am']
print(set(a))
