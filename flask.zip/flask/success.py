from flask import Flask, redirect, url_for, request
app = Flask(__name__)

@app.route('/success/<name>')
def success(senti):
   return 'welcome %s'  % senti

@app.route('/login',methods = ['POST', 'GET'])
def login():
   if request.method == 'POST':
      user = request.form['nm']
      senti = request.form['senti']
      return redirect(url_for('success',name = user,senti=senti))
   else:
      user = request.args.get('nm')
      senti = request.args.get('senti')
      return redirect(url_for('success',name = user, senti =senti))

if __name__ == '__main__':
   app.run(debug = True)
