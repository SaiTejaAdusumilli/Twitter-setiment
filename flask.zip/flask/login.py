from flask import Flask , render_template
app = Flask(__name__)
posts=[{
    'word':'Trump',
    'senti':'negative',
    'prob':'0.43'}]

@app.route("/")
def home():
    return render_template('login1.html',posts=posts)
'''
@app.route('/register', methods=['GET', 'POST'])
def register():
    if flask.request.method == 'POST':
        username = flask.request.values.get('user') # Your form's
        password = flask.request.values.get('pass') # input names
        your_register_routine(username, password)
'''
if __name__ == "__main__":
    app.run(debug=True)


