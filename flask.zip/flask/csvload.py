import re # for regular expressions
import pandas as pd 
pd.set_option("display.max_colwidth", 200)
import numpy as np 
import matplotlib.pyplot as plt 
import seaborn as sns
import string
import nltk # for text manipulation
import warnings 
warnings.filterwarnings("ignore", category=DeprecationWarning)


print("recieved, takes time ----------->")
#message = request.form['message']
message="The families of our wounded warriors don't often get a lot of fanfare, but they're serving and sacrificing right al\xe2\x80\xa6 https://t.co/dNQIaG7WAA"
c=str(message)
print("<----------------taken tweet is : ", c,"----------->")
#combi=df.drop(['id','created_at'],axis=1)
df = pd.read_csv('C://Users//Asus//Desktop//senti//final.csv')
combi=pd.DataFrame()
combi['text']=df['text']
combi['label']=df['label']      
wordlist =set([w for w in nltk.corpus.words.words('en') if w.islower()])
import re
from string import punctuation
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
stopwordss=['i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', "you're", "you've", "you'll", "you'd", 'your', 'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', "she's", 'her', 'hers', 'herself', 'it', "it's", 'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', "that'll", 'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 'at', 'by', 'for', 'with', 'about', 'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such','only', 'own', 'same', 'so', 'than', 'too', 'very', 's', 't', 'can', 'will', 'just', 'don', "don't", 'should', "should've", 'now', 'd', 'll', 'm', 'o', 're', 've', 'y']
def processTweet(tweet):
    lemma  = WordNetLemmatizer()
    
    tweet = tweet.lower()
    
    tweet = re.sub('((www\.[^\s]+)|(https?://[^\s]+))',' ',tweet)
 
    tweet = re.sub('@[^\s]+',' ',tweet)
    
    tweet = re.sub('[\s]+', ' ', tweet)
    
    tweet = tweet.strip('\'"')
    
    tweet = re.sub("[^a-zA-Z#]", " ",tweet)

    tweet=' '.join(lemma.lemmatize(word) for word in tweet.split() if word not in set(stopwordss))
    tweet=' '.join(word for word in tweet.split() if word  in set(wordlist))
    
    return tweet




c=processTweet(c)

#load this combi.to_csv('C://Users//Asus//Desktop//senti//final.csv') 

t=""
for i in c.split():
    if(len(i)>=2):
        t=t+i+" "
c1=pd.DataFrame({"text":[t],"label":[-1]}) 
combi=pd.concat([combi,c1],ignore_index = True)
#print(combi.head())
combi.columns=['tidy_tweet','label']
combi = combi.dropna()
print(combi)
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
import gensim
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
sid = SentimentIntensityAnalyzer()
score = sid.polarity_scores(t)
if(score['compound']>0.4):
    predict=1
elif(score['compound']<-0.4):
    predict=-1
else:
    predict =0

from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
mnb = MultinomialNB(alpha=.01)
mnb.fit(xtrain_bow, ytrain)
mnb_y_pred = mnb.predict(xvalid_bow)
print(accuracy_score(yvalid , mnb_y_pred))
pred = mnb.predict(fff)
print(pred)

print(predict)



bow_vectorizer = CountVectorizer(max_df=0.90, min_df=2, max_features=1000,ngram_range=(1, 3))
bow = bow_vectorizer.fit_transform(combi['tidy_tweet'])
bow.shape



tfidf_vectorizer = TfidfVectorizer(max_df=0.90, min_df=2, max_features=1000)
tfidf = tfidf_vectorizer.fit_transform(combi['tidy_tweet'])
tfidf.shape

fff=tfidf[len(combi)-1]

from sklearn.model_selection import train_test_split
xtrain_bow, xvalid_bow, ytrain, yvalid = train_test_split(tfidf, combi['label'],  
                                                          random_state=42, 
                                                          test_size=0.1)
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
logreg = LogisticRegression(C=0.1).fit(xtrain_bow, ytrain)
y_pred = logreg.predict(xvalid_bow)
print(accuracy_score(yvalid, y_pred))
pred = logreg.predict(fff)
print(pred)
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
mnb = MultinomialNB(alpha=.01)
mnb.fit(xtrain_bow, ytrain)
mnb_y_pred = mnb.predict(xvalid_bow)
print(accuracy_score(yvalid , mnb_y_pred))
pred = mnb.predict(fff)
print(pred)
print("<--->",predict)
