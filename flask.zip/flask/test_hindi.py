from flask import Flask,render_template,url_for,request
app = Flask(__name__)
print("initialized ---------->")
@app.route('/')
def home():
	return render_template('home1.html')
@app.route('/predict',methods=['POST'])
def predict():
    if request.method == 'POST':
        print("recieved, takes time ----------->")
        message = request.form['message']
        #message="The families of our wounded warriors don't often get a lot of fanfare, but they're serving and sacrificing right al\xe2\x80\xa6 https://t.co/dNQIaG7WAA"
        c=str(message)
        print("<----------------taken tweet is : ", c,"----------->")
        
        import numpy as np
        import pandas as pd
        import codecs
        df = pd.read_csv('Hindi.csv')
        #pos_tweets = codecs.open("C://Users//Asus//Desktop//senti//Hindi-pos-NEW.txt",'r','utf-8')
        #neg_tweets = codecs.open("C://Users//Asus//Desktop//senti//Hindi-neg-NEW.txt",'r','utf-8')
        #l=[]
        #for i in pos_tweets:
        #    l.append(i)

        #df1=pd.DataFrame(l,columns=['Tweet'])
        #df1['label']=np.ones(df1.shape[0],dtype=np.int)
        #df1.head()
        #l=[]
        #for i in neg_tweets:
        #    l.append(i)


        #df2=pd.DataFrame(l,columns=['Tweet'])
        #df2['label']=np.zeros(df2.shape[0],dtype=np.int)
        #df2.head()



        #df1.shape,df2.shape



        #df3 = pd.concat([df1, df2], ignore_index=True)

        #df3.shape




        stopwords=[]
        k= codecs.open("Stopwords-hindi-NEW.txt",'r','utf-8')
        for i in k:
            stopwords.append(i)
        l=[]
        for i in stopwords:
            l.append(i.rstrip())



        import re
        from string import punctuation

        #start process_tweet
        def processTweet(tweet):
            emoji_pattern = re.compile("["
                u"\U0001F600-\U0001F64F"  # emoticons
                u"\U0001F300-\U0001F5FF"  # symbols & pictographs
                u"\U0001F680-\U0001F6FF"  # transport & map symbols
                u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
                                   "]+", flags=re.UNICODE)
            tweet=emoji_pattern.sub(r'',tweet)
           
            # process the tweets

            #Convert www.* or https?://* to " "
            tweet = re.sub('((www\.[^\s]+)|(https?://[^\s]+))',' ',tweet)
            
            #Convert @username to "उपयोगकर्ता "
            tweet = re.sub('@[^\s]+','उपयोगकर्ता',tweet)
            #Remove additional white spaces
            tweet = re.sub('[\s]+', ' ', tweet)
            #Replace #word with word
            tweet = re.sub(r'#([^\s]+)', r'\1', tweet)
            #trim
            tweet = tweet.strip('\'"')
            
            tweet=''.join(c for c in tweet if not c.isdigit())
            
            tweet=''.join(c for c in tweet if c not in punctuation)
            
            tweet=' '.join(word for word in tweet.split() if word not in l)
           
            return tweet

        c=processTweet(c)
        combi=pd.DataFrame()
        combi['text']=df['Tweet']
        combi['label']=df['label']
        t=c
        c1=pd.DataFrame({"text":[t],"label":[0]}) 
        combi=pd.concat([combi,c1],ignore_index = True)
        filter = combi['text'] != ""
        combi['text'] = combi[filter]
        combi=combi.dropna()
        df3 = pd.DataFrame()
        df3=combi
        from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
        import gensim


        tfidf_vectorizer = TfidfVectorizer(max_df=0.90, min_df=2, max_features=1000)
        tfidf = tfidf_vectorizer.fit_transform(df3['text'])
        tfidf.shape
        
        fff=tfidf[len(combi)-1]
        
        from sklearn.linear_model import LogisticRegression
        from sklearn.model_selection import train_test_split
        from sklearn.metrics import f1_score




        xtrain_bow, xvalid_bow, ytrain, yvalid = train_test_split(tfidf, df3['label'],  
                                                                  random_state=42, 
                                                                  test_size=0.001)





        logreg = LogisticRegression(C=0.1).fit(xtrain_bow, ytrain)


        log_y_pred = logreg.predict(xvalid_bow)




        from sklearn.metrics import accuracy_score
        logreg_score = accuracy_score(yvalid, log_y_pred)
        print("Accuracy:   {:.3f}".format(logreg_score))
        ypred = logreg.predict(fff)
        print(ypred)
        my_prediction = ypred
        print("completed ----------->")
    return render_template('result1.html',prediction = my_prediction,message=c)        
if __name__ == '__main__':
	app.run(debug=True)
        
